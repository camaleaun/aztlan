<?php
/**
 * Theme starter footer
 *
 * @package Aztec
 */

wp_footer();

?>
</body>
</html>
